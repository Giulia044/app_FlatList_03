import React from 'react';
import { View, Text, Image, StatusBar } from 'react-native';

import Conteudo from './src/componentes/Conteudo';
import { estilos } from './src/styleSheet/estilos';

function App() {
    return (
        <View style={estilos.container}>

            <View style={{ height: StatusBar.currentHeight }} />

            <View style={estilos.cabecalho}>

                <Image
                    source={require('./src/imagens/logo.jpg')}
                    style={estilos.logo}
                />

                <View>

                    <Text style={estilos.titulo}>
                        Maiores Jogos
                    </Text>

                    <Text style={estilos.subtitulo}>
                        da Atualidade
                    </Text>

                </View>

            </View>

            <Conteudo />

        </View>
    );
}

export default App;