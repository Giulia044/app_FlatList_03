import { StyleSheet, Dimensions } from 'react-native';

const largura = Dimensions.get('window').width;

export const estilos = StyleSheet.create({

    container: {
        flex: 1,
        backgroundColor: '#121212',
    },

    cabecalho: {
    backgroundColor: '#1a1a1a',
    padding: 20,
    flexDirection: 'row',
    alignItems: 'center',
    borderBottomWidth: 2,
    borderBottomColor: '#FFD700',
},

    titulo: {
        color: '#ffffff',
        fontSize: 24,
        fontWeight: 'bold',
    },

    card: {
        backgroundColor: '#1f1f1f',
        margin: 15,
        borderRadius: 15,
        padding: 15,
    },

    imagemBase: {
        width: '100%',
        borderRadius: 10,
        alignSelf: 'center',
    },

    rdr2: {
        height: largura * 0.55,
        resizeMode: 'cover',
    },

    minecraft: {
        height: largura * 0.45,
        resizeMode: 'contain',
    },

    eldenring: {
        height: largura * 0.60,
        resizeMode: 'cover',
    },

    gta6: {
        height: largura * 0.50,
        resizeMode: 'contain',
    },

    cyberpunk: {
        height: largura * 0.55,
        resizeMode: 'cover',
    },

    tlou: {
        height: largura * 0.55,
        resizeMode: 'cover',
    },

    fortnite: {
        height: largura * 0.45,
        resizeMode: 'contain',
    },

    gow: {
        height: largura * 0.55,
        resizeMode: 'cover',
    },

    lol: {
        height: largura * 0.45,
        resizeMode: 'contain',
    },

    death: {
        height: largura * 0.55,
        resizeMode: 'cover',
    },

    nome: {
        color: '#fff',
        fontSize: 22,
        fontWeight: 'bold',
        marginTop: 10,
    },

    info: {
        color: '#d1d1d1',
        fontSize: 16,
        marginTop: 5,
    },

    nota: {
        color: '#FFD700',
        fontSize: 18,
        marginTop: 10,
        fontWeight: 'bold',
    },
    logo: {
    width: 80,
    height: 80,
    borderRadius: 40,
    marginRight: 15,
    borderWidth: 3,
    borderColor: '#FFD700',
},

titulo: {
    color: '#ffffff',
    fontSize: 24,
    fontWeight: 'bold',
},

subtitulo: {
    color: '#cccccc',
    fontSize: 16,
    marginTop: 3,
},

});