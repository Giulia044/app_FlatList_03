import React from 'react';
import { View, Text, FlatList, Image } from 'react-native';

import jogos from '../dados/jogos.json';
import { estilos } from '../styleSheet/estilos';

function Conteudo() {

    const imagens = {
        rdr2: require('../imagens/rdr2.png'),
        minecraft: require('../imagens/minecraft.png'),
        eldenring: require('../imagens/eldenring.png'),
        gta6: require('../imagens/gta6.png'),
        cyberpunk: require('../imagens/cyberpunk.png'),
        tlou: require('../imagens/tlou.png'),
        fortnite: require('../imagens/fortnite.png'),
        gow: require('../imagens/gow.png'),
        lol: require('../imagens/lol.png'),
        death: require('../imagens/death.png'),
    };

    function mostrarItem({ item }) {
        return (
            <View style={estilos.card}>

                <Image
                    source={imagens[item.imagem]}
                    style={[estilos.imagemBase, estilos[item.imagem]]}
                />

                <Text style={estilos.nome}>
                    {item.nome}
                </Text>

                <Text style={estilos.info}>
                    Empresa: {item.empresa}
                </Text>

                <Text style={estilos.info}>
                    Gênero: {item.genero}
                </Text>

                <Text style={estilos.info}>
                    Ano: {item.ano}
                </Text>

                <Text style={estilos.nota}>
                    ⭐ Nota: {item.nota}
                </Text>

            </View>
        );
    }

    return (
        <FlatList
            data={jogos}
            renderItem={mostrarItem}
            keyExtractor={(item) => item.id.toString()}
        />
    );
}

export default Conteudo;